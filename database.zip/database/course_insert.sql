INSERT INTO public.course(
	"courseCode", "courseTitle")
	VALUES ('CPEN 207', 'Intro to Software Engineering');