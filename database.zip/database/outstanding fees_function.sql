create function get_outstanding_fees() 
returns json[]
language plpgsql
as $$
Declare
sch_fees json[] ;
Begin
sch_fees:=array(
select fees-"accountBalance" as "outstanding"
into "sch_fees"
from public.student);
return sch_fees; 
End;
$$;