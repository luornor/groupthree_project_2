UPDATE public.student
	SET "courseCode"='CPEN 207';