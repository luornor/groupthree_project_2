INSERT INTO public.is_assigned(
	"courseCode", "lecturerId")
	VALUES ('FAEN 201', 10019),
			('CPEN 201', 10023),
			('CPEN 203', 10017),
			('CPEN 205', 10015),
			('CPEN 207', 10011),
			('CPEN 207', 10013),
			('UGRC 220-238', 10021);