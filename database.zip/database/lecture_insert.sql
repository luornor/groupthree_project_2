INSERT INTO public.lecturer(
	 "firstName", "lastName", "courseCode", "teachingAssistId")
	VALUES ('John', 'Asiamah', 'CPEN 207', 20011);