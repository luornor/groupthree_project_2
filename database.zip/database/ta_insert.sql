INSERT INTO public."teachingAssistant"(
	 "firstName", "lastName")
	VALUES ('Titus', 'Anang');